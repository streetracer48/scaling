import TOGGLE_BUTTON from '../Actions/types';
const initialState = { toggleButton: true };
export default (state = initialState, action) => {
    switch(action.type) {
      case TOGGLE_BUTTON:
        return {
          ...state,
          toggleButton: !state.toggleButton
        }
        default:
          return state
    }
  }