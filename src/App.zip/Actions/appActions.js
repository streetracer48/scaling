import {
    TOGGLE_BUTTON
  } from './types';
  export const toggleButton = () => {
    return {
      type: TOGGLE_BUTTON
    }
  }